# Thinkfan Configuration Notes
This are notes for configuration thinkfan for Fedora. This configuration procedure was followed on a Lenovo Thinkpad T470 running Fedora 32.

Non standard (default) configuration was required for this machine as the default sensors are not available. Eg: `/proc/acpi/ibm/thermal` does not exist for this model.

An annoted configuration file has been included below. However, there is no guarentee that this will work as-is on every machine.

### Installation
```sh
dnf -y install thinkfan
```

### Setup and Configuration
#### Kernel module: coretemp
This step might not be required, but can be performed nonetheless. This is usually required if you cannot fine `coretemp` listed in your loaded modules. You can check for this with the folllowing;
```sh
lsmod | grep coretemp
```
If not found, execute the following command. You can skip `--auto` flag if you want to run in interactive mode.
```sh
dnf -y install lm_sensors
sensors-detect --auto
```
Once completed, you have to either restart the machine or load the kernel modules determined by `sensors-detect`. For the latter, you can execute the following command.
```sh
systemctl restart systemd-modules-load
```

#### Temprature sensors
Once the module is loaded, you can identify the sensors with the help of `find`.
```sh
find /sys/devices -type f -name 'temp*_input'
```
You should see an output similar to what is shown below.
```
# find /sys/devices -type f -name 'temp*_input'
/sys/devices/platform/coretemp.0/hwmon/hwmon4/temp2_input
/sys/devices/platform/coretemp.0/hwmon/hwmon4/temp3_input
/sys/devices/platform/coretemp.0/hwmon/hwmon4/temp1_input
/sys/devices/virtual/hwmon/hwmon2/temp1_input
/sys/devices/virtual/hwmon/hwmon0/temp1_input
/sys/devices/virtual/hwmon/hwmon3/temp1_input
```

#### Configuring thinkfan.conf
The sensors need to be added to `/etc/thinkfan.conf`, but prefixed with `hwmon`. You can append to the config with the following one-liner as root, or manually append it yourself.
```sh
find /sys/devices -type f -name 'temp*_input' | xargs -I {} echo "hwmon {}" >> /etc/thinkfan.conf
```
In order to suppress the warning that it is using the default fan control mechanism, you may also wish to uncomment the following line from the default configuration.
```sh
tp_fan /proc/acpi/ibm/fan
```

#### Enable thinkfan service
This is pretty self explanatory. We want the thinkfan daemon to start at boot.
```sh
systemctl enable thinkfan
```
If you want to start it immediately you can `systemctl start thinkfan`.

#### Configure auto restart of thinkfan service
This is useful since the files in `/sys/devices` can go away and be recreated under certain conditions (eg: system suspend). This, with the default configuration causes the services to crash and require manual intervention. In order to make this a bit less annoying, we can add a systemd drop-in file to tweak the default service specification. For this you need to add a conf file at `/etc/systemd/system/thinkfan.service.d`. Execute the following as root.

```sh
mkdir -p /etc/systemd/system/thinkfan.service.d
cat > /etc/systemd/system/thinkfan.service.d/10-restart-on-failure.conf << EOF
[Unit]
StartLimitIntervalSec=30
StartLimitBurst=3

[Service]
Restart=on-failure
RestartSec=3
EOF
```
Once this is done, reload systemd.
```sh
systemctl daemon-reload
```
The drop-in configuration, tells systemd to [restart the service on-failure](https://www.freedesktop.org/software/systemd/man/systemd.service.html#Restart=) and [wait 3 seconds before restarting](https://www.freedesktop.org/software/systemd/man/systemd.service.html#RestartSec=). The `Unit` section configuration [limits restarts](https://www.freedesktop.org/software/systemd/man/systemd.unit.html#StartLimitIntervalSec=) to 3 times every 30 seconds.

### Troubleshooting
The configuration methodology of using find to dump all your sensor files from `sysfs` could, in certain cases be affected by the order in which modules are loaded by the kernel. For example, on my machine the sensors for `coretemp` and `iwlwifi` swaps between `hwmon3` and `hwmon4` when the machine is awakened after being suspended. To make matters worse, this is inconsistent. This causes the thinkfan daemon to crash and keep crashing until the configuration is updated.

To work around this issue, I hacked together the [thinkfan-config](de81ba413f860b00c2db3ee4aa83e035#file-03-thinkfan-config-sh) script. This uses a template embedded in the script to generate and replace the configuration at `/etc/thinkfan.conf`. Note that this is specific to my system and may not work for other configurations. But you could tweak it based on your needs.

In order to avoid any manual intervention, we can [trigger the script before starting the daemon](https://www.freedesktop.org/software/systemd/man/systemd.service.html#ExecStartPre=). This can be configured as follows, assuming the [thinkfan-config](de81ba413f860b00c2db3ee4aa83e035#file-03-thinkfan-config-sh) script is installed at `/usr/bin/thinkfan-config` and set to be an executable.

```sh
cat > /etc/systemd/system/thinkfan.service.d/00-generate-config.conf << EOF
[Service]
ExecStartPre=-/usr/bin/thinkfan-config
EOF
```

### References
* The man page for thinkfan `man thinkfan` is a good resource.
* The troubleshooting session at http://thinkwiki.de/Thinkfan is the source for majority of the details above.

### Fan Related Bugs
The issues that required the use of thinkfan is listed below. This has been resolved since `4.12.4-1` of the kernel.
* https://wiki.archlinux.org/index.php/Lenovo_ThinkPad_X1_Carbon_(Gen_5)#Bug:_Fans_blowing_at_max_speed_after_resuming
* https://bugzilla.kernel.org/show_bug.cgi?id=191181
