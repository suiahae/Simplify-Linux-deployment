#!/bin/bash

exec $LIBFPRINT_TEST_WRAPPER $@
