#### 1.2.2 fprintd-clients open-fprintd python-validity [2]

https://github.com/uunicorn/python-validity

https://gitter.im/Validity90/Lobby

fedora pam_configuration: 
https://github.com/williamwlk/my-red-corner/blob/master/README_PAM.txt

https://computingforgeeks.com/how-to-setup-built-in-fingerprint-reader-authentication-with-pam-on-any-linux/

https://aur.archlinux.org/packages/fprintd-clients-git/

```bash
sudo dnf install -y libfprint-devel polkit-devel dbus-glib-devel systemd-devel pam-devel pam_wrapper
```

```bash
patch -Np1 < ../disable-systemd-reactivated.diff
meson . ./build
sudo meson install -C build
sudo install -d -m 700 /var/lib/fprint
```

https://aur.archlinux.org/packages/open-fprintd/

```bash
sudo python setup.py build
sudo python setup.py install --prefix=/usr --root /
sudo install -D -m 644 debian/open-fprintd.service /usr/lib/systemd/system/open-fprintd.service
sudo install -D -m 644 debian/open-fprintd-resume.service /usr/lib/systemd/system/open-fprintd-resume.service
sudo install -D -m 644 debian/open-fprintd-suspend.service /usr/lib/systemd/system/open-fprintd-suspend.service
```

https://aur.archlinux.org/packages/python-validity/

```bash
python setup.py build
sudo python setup.py install --prefix=/usr --root /
sudo install -D -m 644 debian/python3-validity.service /usr/lib/systemd/system/python3-validity.service
sudo install -D -m 644 debian/python3-validity.udev /usr/lib/udev/rules.d/60-python-validity.rules
```

```bash
sudo systemctl enable open-fprintd-suspend.service
sudo systemctl enable open-fprintd-resume.service
```

```bash
fprintd-enroll
```
