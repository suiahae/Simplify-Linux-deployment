#### 1.2.3 libfprint [2]

1. 安装环境

    ```bash
    sudo dnf install -y libusb*-devel libtool nss-devel gtk3-devel glib2-devel openssl openssl-devel libXv-devel gcc-c++ libgusb-devel meson cmake gobject-introspection-devel gtk-doc valgrind
    ```

2. 下载并解压

    ```bash
    mkdir libfprint2@3v1n0 && cd libfprint2@3v1n0
    wget https://raw.githubusercontent.com/suiahae/Simplify-Linux-deployment/master/files/libfprint2%403v1n0.zip 
    unzip libfprint2@3v1n0.zip && rm -v libfprint2@3v1n0.zip
    ```

3. 编译

    ```bash
    meson libfprint libfprint/_build
    ```

4. 安装

    ```bash
    sudo ninja -C libfprint/_build install
    ```
