#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <libfprint/fprint.h>

int main (int argc, char **argv)
{
	fp_init ();
	return 0;
}
